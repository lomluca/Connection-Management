// File DLL principale.

#include "stdafx.h"

#include "ConnectionManagement.h"

using namespace System::Threading;

unsigned __stdcall startIOServ(void* data);

ConnectionManagement::UdpServerWrapper::UdpServerWrapper()
{
	boost::asio::io_service io_serv;
	instance = new udp_server(io_serv);
	tcp_server serverTCP(io_serv);
	io_serv.run();
}

unsigned __stdcall startIOServ(void* data) {
	boost::asio::io_service* io_s = (boost::asio::io_service*)data;
	io_s->run();
	return 0;
}


array<ConnectionManagement::Host^>^ ConnectionManagement::UdpServerWrapper::getConnectedHosts() {
	std::list<Peer> peers = instance->getConnectedPeer();
	array<ConnectionManagement::Host^>^ peersToRet = gcnew array<ConnectionManagement::Host^>(peers.size());
	int i = 0;
	for (auto it = peers.begin(); it != peers.end(); it++) {
		peersToRet[i] = gcnew Host(&(*it));
	}
	return peersToRet;
}

ConnectionManagement::Host::Host(Peer* existingUser) {
	instance = existingUser;
}
