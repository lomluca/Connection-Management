// ConnectionManagement.h

#pragma once
#include "c:\Progetto\Progetto\udp_server.h"


using namespace System;

namespace ConnectionManagement {

	public ref class Host
	{
	public:
		Host(Peer* existingUser);

	private:
		Peer* instance;
	};

	public ref class UdpServerWrapper
	{
		// TODO: aggiungere qui i metodi per la classe.
	public:
		UdpServerWrapper();
		array<Host^>^ getConnectedHosts();

	private:
		udp_server* instance;
	};
}
